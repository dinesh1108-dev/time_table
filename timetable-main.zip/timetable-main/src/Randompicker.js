function Randompicker() {
  return <div></div>;
}

export default Randompicker;
